package models;

import entity.Message;
import static dbcontext.GiangDBcontext.getConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MessageDAO {
    
    public List<Message> getMessages(int customerId, Integer shopId) {
        List<Message> messages = new ArrayList<>();
        String sql = "SELECT * FROM Messages WHERE CustomerID = ? " +
                    (shopId != null ? "AND ShopID = ?" : "AND ReceiverType = 'AI'") +
                    " ORDER BY CreatedAt";
                    
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, customerId);
            if (shopId != null) {
                stmt.setInt(2, shopId);
            }
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Message message = new Message();
                message.setMessageId(rs.getInt("MessageID"));
                message.setCustomerId(rs.getInt("CustomerID"));
                message.setShopId(rs.getInt("ShopID"));
                message.setReceiverType(rs.getString("ReceiverType"));
                message.setMessageText(rs.getString("MessageText"));
                message.setStatus(rs.getString("Status"));
                message.setCreatedAt(rs.getTimestamp("CreatedAt"));
                message.setUpdatedAt(rs.getTimestamp("UpdatedAt"));
                messages.add(message);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return messages;
    }

    public void saveMessage(Message message) {
        String sql = "INSERT INTO Messages (CustomerID, ShopID, ReceiverType, MessageText, Status) " +
                    "VALUES (?, ?, ?, ?, ?)";
                    
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, message.getCustomerId());
            if (message.getShopId() != null) {
                stmt.setInt(2, message.getShopId());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }
            stmt.setString(3, message.getReceiverType());
            stmt.setString(4, message.getMessageText());
            stmt.setString(5, "Sent");
            
            stmt.executeUpdate();
            
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                message.setMessageId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
