package controller.Messages;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/chat")
public class MessageServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();

        // For testing purposes, set a dummy customer ID if not present
        if (session.getAttribute("customerId") == null) {
            session.setAttribute("customerId", "1");
        }

        // Forward to chat.jsp
        request.getRequestDispatcher("chat.jsp").forward(request, response);
    }
}