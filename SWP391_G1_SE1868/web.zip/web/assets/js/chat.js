const chatApp = {
    init() {
        this.shopChat = document.getElementById('shop-chat');
        this.aiChat = document.getElementById('ai-chat');
        this.messageList = document.querySelector('.message-list');
        this.messageInput = document.querySelector('.message-input');
        this.shopList = document.querySelector('.shop-list');
        this.tabs = document.querySelectorAll('.tab-item');
        this.typingIndicator = document.createElement('div');
        this.typingIndicator.className = 'typing-indicator hidden';
        this.typingIndicator.innerHTML = '<span>Đang nhập...</span>';
        this.messageList.appendChild(this.typingIndicator);

        this.setupWebSocket();
        this.bindEvents();
        this.loadShops();
    },

    setupWebSocket() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const customerId = document.querySelector('meta[name="customer-id"]').content;

        if (!customerId) {
            console.error('Customer ID not found');
            return;
        }

        this.ws = new WebSocket(`${protocol}//${window.location.host}/chat/${customerId}`);

        this.ws.onopen = () => {
            console.log('WebSocket connection established');
        };

        this.ws.onclose = () => {
            console.log('WebSocket connection closed');
            // Try to reconnect after 5 seconds
            setTimeout(() => this.setupWebSocket(), 5000);
        };

        this.ws.onerror = (error) => {
            console.error('WebSocket error:', error);
        };

        this.ws.onmessage = (event) => {
            try {
                const message = JSON.parse(event.data);
                if (message.type === 'typing') {
                    this.showTypingIndicator(message.userId);
                } else {
                    this.hideTypingIndicator();
                    this.displayMessage(message);
                }
            } catch (error) {
                console.error('Error processing message:', error);
            }
        };
    },

    showTypingIndicator(userId) {
        this.typingIndicator.classList.remove('hidden');
        this.scrollToBottom();
    },

    hideTypingIndicator() {
        this.typingIndicator.classList.add('hidden');
    },

    bindEvents() {
        // Tab switching
        this.tabs.forEach(tab => {
            tab.addEventListener('click', () => {
                this.switchTab(tab.dataset.tab);
            });
        });

        // Send message
        const sendBtn = document.querySelector('.send-btn');
        sendBtn.addEventListener('click', () => this.sendMessage());

        this.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.sendMessage();
            }
        });

        // Typing indicator
        let typingTimeout;
        this.messageInput.addEventListener('input', () => {
            if (this.currentShopId && this.ws.readyState === WebSocket.OPEN) {
                clearTimeout(typingTimeout);
                this.ws.send(JSON.stringify({
                    type: 'typing',
                    userId: document.querySelector('meta[name="customer-id"]').content
                }));
                typingTimeout = setTimeout(() => {
                    if (this.ws.readyState === WebSocket.OPEN) {
                        this.ws.send(JSON.stringify({
                            type: 'stop_typing',
                            userId: document.querySelector('meta[name="customer-id"]').content
                        }));
                    }
                }, 1000);
            }
        });

        // Handle minimize/close
        document.querySelector('.minimize-btn').addEventListener('click', () => {
            document.querySelector('.chat-wrapper').classList.toggle('minimized');
        });

        document.querySelector('.close-btn').addEventListener('click', () => {
            document.querySelector('.chat-wrapper').classList.add('hidden');
        });
    },

    switchTab(tabName) {
        // Update tab active state
        this.tabs.forEach(tab => {
            tab.classList.toggle('active', tab.dataset.tab === tabName);
        });

        // Show/hide chat containers
        this.shopChat.classList.toggle('hidden', tabName !== 'shop');
        this.aiChat.classList.toggle('hidden', tabName !== 'ai');

        if (tabName === 'shop') {
            this.loadMessages(this.currentShopId);
        }
    },

    async loadShops() {
        const response = await fetch('/shops');
        const shops = await response.json();

        this.shopList.innerHTML = shops.map(shop => `
            <div class="shop-item" data-shop-id="${shop.shopId}">
                <img src="${shop.logo}" alt="${shop.name}" class="shop-avatar">
                <div class="shop-info">
                    <span class="shop-name">${shop.name}</span>
                    <span class="shop-status ${shop.status === 'online' ? 'online' : 'offline'}">
                        ${shop.status === 'online' ? 'Online' : 'Offline'}
                    </span>
                </div>
            </div>
        `).join('');

        this.shopList.addEventListener('click', (e) => {
            const shopItem = e.target.closest('.shop-item');
            if (shopItem) {
                this.switchShop(shopItem);
            }
        });
    },

    async switchShop(shopItem) {
        const shopId = shopItem.dataset.shopId;
        this.currentShopId = shopId;

        // Update shop selection UI
        document.querySelectorAll('.shop-item').forEach(item => {
            item.classList.toggle('selected', item === shopItem);
        });

        // Load messages for selected shop
        await this.loadMessages(shopId);
    },

    async loadMessages(shopId) {
        if (!shopId) return;

        const customerId = document.querySelector('meta[name="customer-id"]').content;
        const response = await fetch(`/message?customerId=${customerId}&shopId=${shopId}`);
        const messages = await response.json();

        this.messageList.innerHTML = '';
        messages.forEach(msg => this.displayMessage(msg));
        this.scrollToBottom();
    },

    async sendMessage() {
        const text = this.messageInput.value.trim();
        if (!text || !this.currentShopId) return;

        const customerId = document.querySelector('meta[name="customer-id"]').content;
        const message = {
            customerId: parseInt(customerId),
            shopId: parseInt(this.currentShopId),
            receiverType: 'Shop',
            messageText: text,
            status: 'Sent'
        };

        // Send via WebSocket
        this.ws.send(JSON.stringify(message));

        // Save to database
        await fetch('/message', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(message)
        });

        this.messageInput.value = '';
        this.displayMessage(message);
    },

    displayMessage(message) {
        const isOutgoing = message.customerId === parseInt(document.querySelector('meta[name="customer-id"]').content);
        const messageElement = document.createElement('div');
        messageElement.className = `message ${isOutgoing ? 'outgoing' : 'incoming'}`;

        const avatar = isOutgoing ? '/img/user-avatar.png' :
                      (message.receiverType === 'AI' ? '/img/ai-avatar.png' : '/img/shop-avatar.png');

        messageElement.innerHTML = `
            <div class="message-avatar">
                <img src="${avatar}" alt="Avatar">
            </div>
            <div class="message-content">
                <p>${message.messageText}</p>
                <span class="message-time">${new Date(message.createdAt).toLocaleString()}</span>
                <span class="message-status">${message.status}</span>
            </div>
        `;

        this.messageList.appendChild(messageElement);
        this.scrollToBottom();
    },

    scrollToBottom() {
        this.messageList.scrollTop = this.messageList.scrollHeight;
    }
};

document.addEventListener('DOMContentLoaded', () => chatApp.init());